package ml.maxcraftmc.maxkookbot;

public class Main {
}

package ml.maxcraftmc.maxkookbot;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import ml.maxcraftmc.maxkookbot.KookMan;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

public final class MaxKookBot extends JavaPlugin {
    KookMan KookBotMan;
    @Override
    public void onEnable() {
        // Plugin startup logic
        File configFile = new File(this.getDataFolder()+ File.separator+"config.yml");
        FileConfiguration pluginConfiguration = YamlConfiguration.loadConfiguration(configFile);
        if (pluginConfiguration.get("token", "YourTokenHere") == "YourTokenHere"){
            pluginConfiguration.set("token", "YourTokenHere");
            try {
                pluginConfiguration.save(configFile);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            KookBotMan = new KookMan(pluginConfiguration.get("token").toString(), getLogger());
        }

        this.getLogger().log(Level.INFO, "KookMan对象构造完成");
        try {
            KookBotMan.BotConnect();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}

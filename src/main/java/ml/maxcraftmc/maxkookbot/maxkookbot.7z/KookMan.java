package ml.maxcraftmc.maxkookbot;


import okhttp3.*;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;


public class KookMan {
    private static final String _BaseURL = "https://www.kookapp.cn";
    private OkHttpClient _client;
    private Logger log;
    public KookMan(String token, Logger logger) {
        log = logger;
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.addInterceptor(new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request request = chain.request();
                Request.Builder reqBuilder = request.newBuilder();
                reqBuilder.addHeader("Authorization", "Bot " + token);
                request = reqBuilder.build();
                return chain.proceed(request);
            }
        });
        _client = builder.build();
    }

    public String get(String path) throws IOException {
        Request request = new Request.Builder()
                .url(_BaseURL + path)
                .get()
                .build();
        Response response = _client.newCall(request).execute();
        return response.body().string();
    }

    public String websocketGetGateway() throws IOException {
        Request request = new Request.Builder()
                .url(_BaseURL + "/api/v3/gateway/index")
                .get()
                .build();
        Response response = _client.newCall(request).execute();
        String resp = response.body().string();
        log.log(Level.INFO,resp);
        String start = "\"url\":\"";
        int startIndex = resp.indexOf(start);
        int endIndex = resp.indexOf("\"", startIndex + start.length());
        return resp.substring(startIndex + start.length(), endIndex);
    }


    public void WebsocketConnect(String wsURL) throws InterruptedException {
        Request request = new Request.Builder()
                .url(wsURL)
                .get()
                .build();
        CountDownLatch latch = new CountDownLatch(1);
        WebSocket webSocket = _client.newWebSocket(request, new WebSocketListener()
        {
            @Override
            public void onOpen(WebSocket webSocket, Response response)
            {
                log.log(Level.INFO, "Websocket connected!");
                latch.countDown(); // 打开latch
            }

            // ...
        });

        // 如果2秒内未收到onOpen回调,连接失败
        int WAIT_TIME = 2000;
        if (!waitSocketConnected(latch, WAIT_TIME)) {
            log.log(Level.WARNING, "Websocket connection failed!");
        }
    }

    // 等待CountDownLatch
    private boolean waitSocketConnected(CountDownLatch latch, int waitTime) throws InterruptedException
    {
        return latch.await(waitTime, TimeUnit.MILLISECONDS);
    }

    public void BotConnect() throws IOException, InterruptedException {
        WebsocketConnect(websocketGetGateway());
    }
}